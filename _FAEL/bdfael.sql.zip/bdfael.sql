-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 04-01-2010 a las 10:49:51
-- Versión del servidor: 5.0.18
-- Versión de PHP: 5.1.2
-- 
-- Base de datos: `bdfael`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `pempresa`
-- 

CREATE TABLE `pempresa` (
  `emp_nit` int(11) NOT NULL,
  `emp_nombre` varchar(50) NOT NULL,
  `emp_propietario` varchar(50) NOT NULL,
  `emp_direccion` varchar(50) NOT NULL,
  `emp_resolucion` varchar(50) NOT NULL,
  `emp_telefono` varchar(10) NOT NULL,
  `emp_celular` varchar(10) NOT NULL,
  `emp_email` varchar(30) NOT NULL,
  `emp_notas` text,
  `emp_regimen` varchar(10) NOT NULL,
  PRIMARY KEY  (`emp_nit`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `pempresa`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `pusr`
-- 

CREATE TABLE `pusr` (
  `usr_id` int(11) NOT NULL,
  `usr_nombre` varchar(15) NOT NULL,
  `usr_pass` varchar(15) NOT NULL,
  `usr_tipo` int(11) NOT NULL,
  `usr_activo` binary(1) NOT NULL default '0',
  PRIMARY KEY  (`usr_id`),
  KEY `User` (`usr_nombre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Volcar la base de datos para la tabla `pusr`
-- 

INSERT INTO `pusr` VALUES (97611607, 'FRANCISCO', 'KN', 1, 0x31);
INSERT INTO `pusr` VALUES (1, 'SONIA', '‰…„w', 2, 0x31);
INSERT INTO `pusr` VALUES (41211907, 'FIDELINA', 'ƒwƒw', 1, 0x31);
INSERT INTO `pusr` VALUES (41241368, 'MARTHA', 'ˆwƒ…‰', 2, 0x31);
INSERT INTO `pusr` VALUES (97612856, 'KOALME', 'GH', 1, 0x31);
